# نظام إدارة الإجازات — Web جاهز للنشر

نسخة Next.js + Supabase مع تسجيل دخول وحساب جديد، Dashboard، إدخال موظفين، وتسجيل الإجازات.

## التشغيل
1. ثبّت Node.js.
2. نفّذ `npm install`.
3. أنشئ `.env.local` من `.env.example` وضع Project URL وPublishable Key.
4. نفّذ `npm run dev`.

## Supabase
شغّل `supabase/schema.sql` مرة واحدة في SQL Editor.

## النشر
ارفع المشروع إلى GitHub ثم اربطه بـ Vercel، وأضف متغيرات البيئة نفسها في إعدادات Vercel.

مهم: لا تضع Secret/Service Role Key في الواجهة.
